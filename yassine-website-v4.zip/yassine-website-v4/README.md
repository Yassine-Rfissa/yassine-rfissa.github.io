Yassine Rfissa — Academic Website V4

Upload index.html AND the assets folder (including yassine-rfissa.png) to the ROOT of your GitHub Pages repository.

To update GitHub via browser: Add file > Upload files, drag both index.html and the assets folder, then Commit changes. If GitHub browser does not accept a folder, create an assets folder using Add file > Create new file and name it assets/.gitkeep, commit, then upload the image inside assets and index.html at the root.

This is a static site; no build process, package manager, or API keys. Book cover is conceptual. Verify publication statuses and affiliations before treating as a final public CV.
