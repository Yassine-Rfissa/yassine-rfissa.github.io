# Yassine Rfissa — academic author website (Version 5)

## Deploy to GitHub Pages
1. Unzip this package.
2. In the GitHub repository `Yassine-Rfissa/yassine-rfissa.github.io`, choose **Add file → Upload files**.
3. Upload `index.html` AND the `assets` folder, preserving `assets/yassine-rfissa.png`.
4. Commit the changes. If GitHub warns that `index.html` exists, use the repository file editor to replace its contents, or remove the old `index.html` before uploading the new one.
5. Wait for GitHub Pages deployment; visit https://yassine-rfissa.github.io/ and hard-refresh.

## Official book covers
Online retailer listings for both books were located, but the actual cover image files could not be downloaded and verified in this environment. The displayed book artwork is **explicitly conceptual** and should be replaced with your official cover images when you upload them. Do not present these placeholders as publisher artwork.

The End of Knowing (2026), ISBN 9798182243469:
https://www.whiterainbookhouse.com/products/the-end-of-knowing-yassine-rfissa-9798182243469

EFL Prepositional Error Analysis (2023), ISBN 9786206143833:
https://www.michaelsbund.de/product/9786206143833-efl-prepositional-error-analysis.html

## Updating content
The whole site is self-contained in `index.html`, apart from the portrait and Google Fonts. Change the text directly in the HTML. The contact email currently uses yrfissa@unomaha.edu. The site does not require Node, a build step, or any paid hosting.

## Editorial review
Confirm membership currency, recent conference presentation status, and any new publication records before announcing this site as a comprehensive CV. Site is an independent personal website, not an official UNO page.
